const express = require('express');
const { registerPonto } = require('./puppeteerHelper');

function startAPI() {
  const app = express();
  app.use(express.json());

  app.post('/api/registrar', async (req, res) => {
    const { employerCode, pin } = req.body;

    if (!employerCode || !pin) {
      return res.status(400).json({ error: 'Faltam parâmetros' });
    }

    try {
      await registerPonto(employerCode, pin);
      return res.json({ status: 'Ponto registrado com sucesso' });
    } catch (error) {
      return res.status(500).json({ error: 'Erro ao registrar ponto' });
    }
  });

  const PORT = 3000;
  app.listen(PORT, () => {
    console.log(`🚀 API rodando em http://localhost:${PORT}`);
  });
}

module.exports = startAPI;